@echo off
rem Hiko OS launcher: opens Hiko in its own app window (Microsoft Edge)
start "" msedge --app="file:///%~dp0Hiko.html" --start-maximized
if errorlevel 1 start "" "%~dp0Hiko.html"
